try:
    n1 = int(input("Enter a number: "))
    dad
except ValueError as e:
    print('Enter a value valid.')
except NameError as e:
    print(e)