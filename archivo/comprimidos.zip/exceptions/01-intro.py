try:
    n1 = int(input("enter a first number: "))
except:
    print('not valid number, enter a number')
