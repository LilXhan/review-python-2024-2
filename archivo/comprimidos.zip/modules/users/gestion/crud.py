def save():
    print('saved')