from users.impuestos.utilitys import pay 
# import users

pay()
print(__name__)

# print(users.__package__)
# print(users.__path__)
# print(users.__name__)
# print(users.__file__)