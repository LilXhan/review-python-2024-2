def init(db, api, **_):
    print(f"i'm module two: {db} , {api}")